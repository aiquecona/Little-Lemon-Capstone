import React from "react";
import { Link } from "react-router-dom";
import bannerImg from '../images/kit.jpg'

const Header = () => {
    return (
        <header className="header">
            <section>
                <div className="banner">
                <h2>Little Lemon Restaurant</h2>
                <h3>Brisbane</h3>
                <p>Little Lemon is a cozy restaurant offering delightful Mediterranean cuisine. 
                    Known for fresh, locally sourced ingredients,it features zesty seafood, 
                    grilled meats, and vibrant vegetarian dishes.</p>
                <Link to= "/booking"><button aria-label='On Click'>Book a table</button></Link>
                </div>

                <div className='banner-img'>
                    <img src={bannerImg} alt='' />
                </div>
            </section>


        </header>

    );
};
export default Header;